package dev.arun.nexhomes.gui;

import dev.arun.nexhomes.NexHomes;
import dev.arun.nexhomes.utils.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public class ConfirmDeleteGUI implements InventoryHolder {

    private final Inventory inventory;
    private final int homeSlot;
    private final String homeName;
    private final int returnPage;

    public static final NamespacedKey CONFIRM_ACTION_KEY = new NamespacedKey("nexhomes", "confirm_action");

    public ConfirmDeleteGUI(NexHomes plugin, int homeSlot, String homeName, int returnPage) {
        this.homeSlot = homeSlot;
        this.homeName = homeName;
        this.returnPage = returnPage;

        int size = plugin.getConfig().getInt("confirm-gui.size", 36);
        String title = plugin.getConfig().getString("confirm-gui.title", "Confirm Delete")
                .replace("%slot%", String.valueOf(homeSlot))
                .replace("%name%", homeName);
        this.inventory = Bukkit.createInventory(this, size, ColorUtil.color(title));

        placeButton(plugin, "confirm-gui.cancel-top", 12, Material.RED_STAINED_GLASS_PANE, "CANCEL");
        placeButton(plugin, "confirm-gui.cancel-bottom", 21, Material.RED_DYE, "CANCEL");
        placeButton(plugin, "confirm-gui.confirm-top", 14, Material.LIME_STAINED_GLASS_PANE, "CONFIRM");
        placeButton(plugin, "confirm-gui.confirm-bottom", 23, Material.LIME_DYE, "CONFIRM");
        placeButton(plugin, "confirm-gui.back", 22, Material.BARRIER, "BACK");
    }

    private void placeButton(NexHomes plugin, String path, int defaultSlot, Material fallbackMat, String action) {
        int slot = plugin.getConfig().getInt(path + ".slot", defaultSlot);
        String matName = plugin.getConfig().getString(path + ".material");
        Material mat = matName != null ? Material.matchMaterial(matName.toUpperCase()) : null;
        if (mat == null) mat = fallbackMat;

        String name = plugin.getConfig().getString(path + ".name", action)
                .replace("%slot%", String.valueOf(homeSlot))
                .replace("%name%", homeName);
        List<String> lore = new ArrayList<>();
        for (String line : plugin.getConfig().getStringList(path + ".lore")) {
            lore.add(line.replace("%slot%", String.valueOf(homeSlot)).replace("%name%", homeName));
        }

        inventory.setItem(slot, makeButton(mat, name, lore, action));
    }

    private ItemStack makeButton(Material material, String name, List<String> lore, String action) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ColorUtil.color(name));
            if (lore != null && !lore.isEmpty()) {
                meta.setLore(ColorUtil.colorList(lore));
            }
            meta.getPersistentDataContainer().set(CONFIRM_ACTION_KEY, PersistentDataType.STRING, action);
            item.setItemMeta(meta);
        }
        return item;
    }

    public int getHomeSlot() {
        return homeSlot;
    }

    public String getHomeName() {
        return homeName;
    }

    public int getReturnPage() {
        return returnPage;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
