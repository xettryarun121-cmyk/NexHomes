package dev.arun.nexhomes.listeners;

import dev.arun.nexhomes.NexHomes;
import dev.arun.nexhomes.gui.ConfirmDeleteGUI;
import dev.arun.nexhomes.gui.HomeGUI;
import dev.arun.nexhomes.model.HomeData;
import dev.arun.nexhomes.utils.ColorUtil;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.Map;

public class GUIListener implements Listener {

    private final NexHomes plugin;

    public GUIListener(NexHomes plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        InventoryHolder holder = event.getInventory().getHolder();
        if (!(holder instanceof HomeGUI || holder instanceof ConfirmDeleteGUI)) return;
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) return;
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || !clicked.hasItemMeta()) return;

        ItemMeta meta = clicked.getItemMeta();
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        String prefix = plugin.getConfig().getString("prefix", "&#7cf000&lHOMES &r");

        if (holder instanceof ConfirmDeleteGUI confirmGui) {
            String confirmAction = pdc.get(ConfirmDeleteGUI.CONFIRM_ACTION_KEY, PersistentDataType.STRING);
            if (confirmAction == null) return;

            switch (confirmAction) {
                case "CONFIRM" -> {
                    plugin.getHomeManager().deleteHomeSlot(player.getUniqueId(), confirmGui.getHomeSlot());
                    String msg = plugin.getConfig().getString("messages.home-deleted", "%prefix%&cDeleted!")
                            .replace("%prefix%", prefix)
                            .replace("%name%", confirmGui.getHomeName())
                            .replace("%slot%", String.valueOf(confirmGui.getHomeSlot()));
                    player.sendMessage(ColorUtil.color(msg));
                    player.playSound(player.getLocation(), Sound.ENTITY_ITEM_BREAK, 1f, 1f);
                    player.openInventory(new HomeGUI(plugin, player, confirmGui.getReturnPage()).getInventory());
                }
                case "CANCEL", "BACK" -> {
                    player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1f, 1f);
                    player.openInventory(new HomeGUI(plugin, player, confirmGui.getReturnPage()).getInventory());
                }
            }
            return;
        }

        HomeGUI gui = (HomeGUI) holder;
        String action = pdc.get(HomeGUI.ACTION_KEY, PersistentDataType.STRING);
        if (action == null || action.equals("NONE")) return;

        switch (action) {
            case "PREV_PAGE" -> {
                player.playSound(player.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 1f, 1.2f);
                player.openInventory(new HomeGUI(plugin, player, gui.getPage() - 1).getInventory());
            }
            case "NEXT_PAGE" -> {
                player.playSound(player.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 1f, 1.2f);
                player.openInventory(new HomeGUI(plugin, player, gui.getPage() + 1).getInventory());
            }
            case "LOCKED" -> {
                player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            }
            case "SET_EMPTY" -> {
                Integer slotNum = pdc.get(HomeGUI.SLOT_NUM_KEY, PersistentDataType.INTEGER);
                if (slotNum == null) return;

                int maxHomes = plugin.getHomeManager().getMaxHomes(player);
                Map<Integer, HomeData> currentHomes = plugin.getHomeManager().getHomesBySlot(player.getUniqueId());

                if (slotNum > maxHomes || currentHomes.size() >= maxHomes) {
                    String msg = plugin.getConfig().getString("messages.max-homes-reached", "%prefix%&cLimit reached!")
                            .replace("%prefix%", prefix)
                            .replace("%max%", String.valueOf(maxHomes));
                    player.sendMessage(ColorUtil.color(msg));
                    player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
                    return;
                }

                String homeName = "home" + slotNum;
                plugin.getHomeManager().setHomeInSlot(player, slotNum, homeName, player.getLocation());

                String msg = plugin.getConfig().getString("messages.home-set", "%prefix%&aHome set!")
                        .replace("%prefix%", prefix)
                        .replace("%name%", homeName)
                        .replace("%slot%", String.valueOf(slotNum));
                player.sendMessage(ColorUtil.color(msg));
                player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.2f);
                player.openInventory(new HomeGUI(plugin, player, gui.getPage()).getInventory());
            }
            case "TELEPORT_HOME" -> {
                Integer slotNum = pdc.get(HomeGUI.SLOT_NUM_KEY, PersistentDataType.INTEGER);
                if (slotNum == null) return;
                HomeData data = plugin.getHomeManager().getHomesBySlot(player.getUniqueId()).get(slotNum);
                if (data != null) {
                    player.closeInventory();
                    player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1f, 1.2f);
                    plugin.getHomeManager().teleportWithWarmup(player, data.getName(), data.getLocation());
                }
            }
            case "CONFIRM_DELETE" -> {
                Integer slotNum = pdc.get(HomeGUI.SLOT_NUM_KEY, PersistentDataType.INTEGER);
                if (slotNum == null) return;
                HomeData data = plugin.getHomeManager().getHomesBySlot(player.getUniqueId()).get(slotNum);
                if (data != null) {
                    player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1f, 1f);
                    player.openInventory(new ConfirmDeleteGUI(plugin, slotNum, data.getName(), gui.getPage()).getInventory());
                }
            }
        }
    }
}
