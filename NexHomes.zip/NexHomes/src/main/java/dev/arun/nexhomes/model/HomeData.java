package dev.arun.nexhomes.model;

import org.bukkit.Location;

public class HomeData {
    private final int slot;
    private final String name;
    private final Location location;

    public HomeData(int slot, String name, Location location) {
        this.slot = slot;
        this.name = name;
        this.location = location;
    }

    public int getSlot() {
        return slot;
    }

    public String getName() {
        return name;
    }

    public Location getLocation() {
        return location;
    }
}
