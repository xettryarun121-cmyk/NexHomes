package dev.arun.nexhomes.commands;

import dev.arun.nexhomes.NexHomes;
import dev.arun.nexhomes.gui.HomeGUI;
import dev.arun.nexhomes.model.HomeData;
import dev.arun.nexhomes.utils.ColorUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class HomeCommands implements CommandExecutor, TabCompleter {

    private final NexHomes plugin;

    public HomeCommands(NexHomes plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String prefix = plugin.getConfig().getString("prefix", "&#7cf000&lHOMES &r");

        if (command.getName().equalsIgnoreCase("nexhomes")) {
            if (!sender.hasPermission("nexhomes.admin")) {
                sender.sendMessage(ColorUtil.color(prefix + "&cNo permission."));
                return true;
            }
            if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
                plugin.reloadConfig();
                String msg = plugin.getConfig().getString("messages.reloaded", "%prefix%&aReloaded!")
                        .replace("%prefix%", prefix);
                sender.sendMessage(ColorUtil.color(msg));
            }
            return true;
        }

        if (!(sender instanceof Player player)) {
            sender.sendMessage(ColorUtil.color(plugin.getConfig().getString("messages.only-players", "&cPlayers only.")));
            return true;
        }

        Map<Integer, HomeData> homesBySlot = plugin.getHomeManager().getHomesBySlot(player.getUniqueId());

        switch (command.getName().toLowerCase()) {
            case "homes" -> {
                int page = 1;
                if (args.length > 0) {
                    try {
                        page = Integer.parseInt(args[0]);
                    } catch (NumberFormatException ignored) {}
                }
                player.openInventory(new HomeGUI(plugin, player, page).getInventory());
            }

            case "sethome" -> {
                HomeData existing = args.length > 0 ? plugin.getHomeManager().getHomeByName(player.getUniqueId(), args[0]) : null;
                if (existing != null) {
                    plugin.getHomeManager().setHomeInSlot(player, existing.getSlot(), existing.getName(), player.getLocation());
                    String msg = plugin.getConfig().getString("messages.home-set", "%prefix%&aHome updated!")
                            .replace("%prefix%", prefix)
                            .replace("%name%", existing.getName())
                            .replace("%slot%", String.valueOf(existing.getSlot()));
                    player.sendMessage(ColorUtil.color(msg));
                    return true;
                }

                int targetSlot = plugin.getHomeManager().getFirstAvailableSlot(player);
                if (targetSlot == -1) {
                    int maxHomes = plugin.getHomeManager().getMaxHomes(player);
                    String msg = plugin.getConfig().getString("messages.max-homes-reached", "%prefix%&cLimit reached!")
                            .replace("%prefix%", prefix)
                            .replace("%max%", String.valueOf(maxHomes));
                    player.sendMessage(ColorUtil.color(msg));
                    return true;
                }

                String name = args.length > 0 ? args[0].toLowerCase() : "home" + targetSlot;
                plugin.getHomeManager().setHomeInSlot(player, targetSlot, name, player.getLocation());

                String msg = plugin.getConfig().getString("messages.home-set", "%prefix%&aHome set!")
                        .replace("%prefix%", prefix)
                        .replace("%name%", name)
                        .replace("%slot%", String.valueOf(targetSlot));
                player.sendMessage(ColorUtil.color(msg));
            }

            case "delhome" -> {
                if (args.length == 0) {
                    player.sendMessage(ColorUtil.color(prefix + "&cUsage: /delhome <name>"));
                    return true;
                }
                HomeData target = plugin.getHomeManager().getHomeByName(player.getUniqueId(), args[0]);
                if (target != null && plugin.getHomeManager().deleteHomeSlot(player.getUniqueId(), target.getSlot())) {
                    String msg = plugin.getConfig().getString("messages.home-deleted", "%prefix%&cDeleted %name%!")
                            .replace("%prefix%", prefix)
                            .replace("%name%", target.getName())
                            .replace("%slot%", String.valueOf(target.getSlot()));
                    player.sendMessage(ColorUtil.color(msg));
                } else {
                    String msg = plugin.getConfig().getString("messages.home-not-found", "%prefix%&cNot found!")
                            .replace("%prefix%", prefix)
                            .replace("%name%", args[0]);
                    player.sendMessage(ColorUtil.color(msg));
                }
            }

            case "home" -> {
                if (args.length == 0) {
                    player.openInventory(new HomeGUI(plugin, player, 1).getInventory());
                    return true;
                }
                HomeData target = plugin.getHomeManager().getHomeByName(player.getUniqueId(), args[0]);
                if (target != null) {
                    plugin.getHomeManager().teleportWithWarmup(player, target.getName(), target.getLocation());
                } else {
                    String msg = plugin.getConfig().getString("messages.home-not-found", "%prefix%&cNot found!")
                            .replace("%prefix%", prefix)
                            .replace("%name%", args[0]);
                    player.sendMessage(ColorUtil.color(msg));
                }
            }
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!(sender instanceof Player player)) return List.of();
        if (args.length == 1 && (command.getName().equalsIgnoreCase("home") || command.getName().equalsIgnoreCase("delhome"))) {
            List<String> names = new ArrayList<>();
            for (HomeData data : plugin.getHomeManager().getHomesBySlot(player.getUniqueId()).values()) {
                names.add(data.getName());
            }
            return names;
        }
        return List.of();
    }
}
