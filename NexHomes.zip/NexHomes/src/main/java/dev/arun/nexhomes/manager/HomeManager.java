package dev.arun.nexhomes.manager;

import dev.arun.nexhomes.NexHomes;
import dev.arun.nexhomes.model.HomeData;
import dev.arun.nexhomes.utils.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.permissions.PermissionAttachmentInfo;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class HomeManager {

    private final NexHomes plugin;
    private final File homesFile;
    private FileConfiguration homesConfig;
    private final Map<UUID, BukkitTask> pendingTeleports = new HashMap<>();

    public HomeManager(NexHomes plugin) {
        this.plugin = plugin;
        this.homesFile = new File(plugin.getDataFolder(), "homes.yml");
        if (!homesFile.exists()) {
            try {
                homesFile.getParentFile().mkdirs();
                homesFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        this.homesConfig = YamlConfiguration.loadConfiguration(homesFile);
    }

    public void saveHomesFile() {
        try {
            homesConfig.save(homesFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public int getMaxHomes(Player player) {
        int maxAllowed = plugin.getConfig().getInt("max-pages", 10) * 7; // Up to 70 slots (10 pages)
        if (player.isOp() || player.hasPermission("nexhomes.admin")) {
            return maxAllowed;
        }
        int limit = plugin.getConfig().getInt("default-max-homes", 3);
        for (PermissionAttachmentInfo info : player.getEffectivePermissions()) {
            if (info.getValue() && info.getPermission().startsWith("nexhomes.max.")) {
                try {
                    int permLimit = Integer.parseInt(info.getPermission().substring("nexhomes.max.".length()));
                    if (permLimit > limit) {
                        limit = permLimit;
                    }
                } catch (NumberFormatException ignored) {}
            }
        }
        return Math.min(limit, maxAllowed);
    }

    /**
     * Returns homes keyed by their fixed 1-based slot number so deleting slot 2
     * leaves slot 2 empty and keeps slot 3 in slot 3.
     */
    public Map<Integer, HomeData> getHomesBySlot(UUID uuid) {
        Map<Integer, HomeData> slotMap = new TreeMap<>();
        ConfigurationSection section = homesConfig.getConfigurationSection(uuid.toString());
        if (section == null) return slotMap;

        for (String key : section.getKeys(false)) {
            int slot;
            try {
                slot = Integer.parseInt(key);
            } catch (NumberFormatException e) {
                continue;
            }
            String name = section.getString(key + ".name", "home" + slot);
            String worldName = section.getString(key + ".world");
            World world = worldName != null ? Bukkit.getWorld(worldName) : null;
            if (world != null) {
                double x = section.getDouble(key + ".x");
                double y = section.getDouble(key + ".y");
                double z = section.getDouble(key + ".z");
                float yaw = (float) section.getDouble(key + ".yaw");
                float pitch = (float) section.getDouble(key + ".pitch");
                slotMap.put(slot, new HomeData(slot, name, new Location(world, x, y, z, yaw, pitch)));
            }
        }
        return slotMap;
    }

    public HomeData getHomeByName(UUID uuid, String name) {
        for (HomeData data : getHomesBySlot(uuid).values()) {
            if (data.getName().equalsIgnoreCase(name)) {
                return data;
            }
        }
        return null;
    }

    public int getFirstAvailableSlot(Player player) {
        int maxHomes = getMaxHomes(player);
        Map<Integer, HomeData> current = getHomesBySlot(player.getUniqueId());
        for (int slot = 1; slot <= maxHomes; slot++) {
            if (!current.containsKey(slot)) {
                return slot;
            }
        }
        return -1;
    }

    public void setHomeInSlot(Player player, int slot, String name, Location loc) {
        String path = player.getUniqueId() + "." + slot;
        homesConfig.set(path + ".name", name);
        homesConfig.set(path + ".world", loc.getWorld().getName());
        homesConfig.set(path + ".x", loc.getX());
        homesConfig.set(path + ".y", loc.getY());
        homesConfig.set(path + ".z", loc.getZ());
        homesConfig.set(path + ".yaw", loc.getYaw());
        homesConfig.set(path + ".pitch", loc.getPitch());
        saveHomesFile();
    }

    public boolean deleteHomeSlot(UUID uuid, int slot) {
        String path = uuid.toString() + "." + slot;
        if (!homesConfig.contains(path)) return false;
        homesConfig.set(path, null);
        saveHomesFile();
        return true;
    }

    public void teleportWithWarmup(Player player, String homeName, Location target) {
        cancelTeleport(player);

        int warmup = plugin.getConfig().getInt("teleport-warmup", 5);
        String prefix = plugin.getConfig().getString("prefix", "&#7cf000&lHOMES &r");

        if (warmup <= 0 || player.hasPermission("nexhomes.bypass.warmup")) {
            player.teleport(target);
            String msg = plugin.getConfig().getString("messages.teleported", "%prefix%&aTeleported!")
                    .replace("%prefix%", prefix)
                    .replace("%name%", homeName);
            player.sendMessage(ColorUtil.color(msg));
            return;
        }

        Location startLoc = player.getLocation().getBlock().getLocation();

        BukkitTask task = Bukkit.getScheduler().runTaskTimer(plugin, new Runnable() {
            int remaining = warmup;

            @Override
            public void run() {
                if (!player.isOnline()) {
                    cancelTeleport(player);
                    return;
                }

                if (plugin.getConfig().getBoolean("cancel-on-move", true)) {
                    Location currentLoc = player.getLocation().getBlock().getLocation();
                    if (!currentLoc.equals(startLoc)) {
                        String cancelMsg = plugin.getConfig().getString("messages.teleport-cancelled", "%prefix%&cCancelled!")
                                .replace("%prefix%", prefix);
                        player.sendMessage(ColorUtil.color(cancelMsg));
                        cancelTeleport(player);
                        return;
                    }
                }

                if (remaining <= 0) {
                    player.teleport(target);
                    String doneMsg = plugin.getConfig().getString("messages.teleported", "%prefix%&aTeleported!")
                            .replace("%prefix%", prefix)
                            .replace("%name%", homeName);
                    player.sendMessage(ColorUtil.color(doneMsg));
                    cancelTeleport(player);
                    return;
                }

                String tickMsg = plugin.getConfig().getString("messages.teleporting", "%prefix%&fTeleporting in &a%seconds%s&f...")
                        .replace("%prefix%", prefix)
                        .replace("%name%", homeName)
                        .replace("%seconds%", String.valueOf(remaining));
                player.sendMessage(ColorUtil.color(tickMsg));
                player.sendActionBar(ColorUtil.color(tickMsg));
                remaining--;
            }
        }, 0L, 20L);

        pendingTeleports.put(player.getUniqueId(), task);
    }

    public void cancelTeleport(Player player) {
        BukkitTask task = pendingTeleports.remove(player.getUniqueId());
        if (task != null) {
            task.cancel();
        }
    }
}
