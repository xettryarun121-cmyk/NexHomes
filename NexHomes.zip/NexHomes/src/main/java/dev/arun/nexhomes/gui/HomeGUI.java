package dev.arun.nexhomes.gui;

import dev.arun.nexhomes.NexHomes;
import dev.arun.nexhomes.model.HomeData;
import dev.arun.nexhomes.utils.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class HomeGUI implements InventoryHolder {

    private final NexHomes plugin;
    private final Player player;
    private final int page;
    private final Inventory inventory;

    public static final NamespacedKey ACTION_KEY = new NamespacedKey("nexhomes", "action");
    public static final NamespacedKey SLOT_NUM_KEY = new NamespacedKey("nexhomes", "slot_num");
    public static final NamespacedKey PAGE_NUM_KEY = new NamespacedKey("nexhomes", "page_num");

    public HomeGUI(NexHomes plugin, Player player, int page) {
        this.plugin = plugin;
        this.player = player;
        int maxPages = plugin.getConfig().getInt("max-pages", 10);
        this.page = Math.max(1, Math.min(page, maxPages));

        int size = plugin.getConfig().getInt("gui.size", 36);
        String rawTitle = plugin.getConfig().getString("gui.title", "Homes ! Page: %page%")
                .replace("%page%", String.valueOf(this.page))
                .replace("%max_pages%", String.valueOf(maxPages));

        this.inventory = Bukkit.createInventory(this, size, ColorUtil.color(rawTitle));
        setupItems();
    }

    private void setupItems() {
        Map<Integer, HomeData> homesBySlot = plugin.getHomeManager().getHomesBySlot(player.getUniqueId());
        int maxHomes = plugin.getHomeManager().getMaxHomes(player);

        List<Integer> topSlots = plugin.getConfig().getIntegerList("gui.top-slots");
        List<Integer> bottomSlots = plugin.getConfig().getIntegerList("gui.bottom-slots");
        if (topSlots.isEmpty()) topSlots = List.of(10, 11, 12, 13, 14, 15, 16);
        if (bottomSlots.isEmpty()) bottomSlots = List.of(19, 20, 21, 22, 23, 24, 25);

        int itemsPerPage = Math.min(topSlots.size(), bottomSlots.size());
        int startSlot = (page - 1) * itemsPerPage + 1;

        for (int i = 0; i < itemsPerPage; i++) {
            int displaySlot = startSlot + i;
            HomeData homeData = homesBySlot.get(displaySlot);

            if (homeData != null) {
                // Active Home in this specific slot
                inventory.setItem(topSlots.get(i), buildConfiguredItem("gui.set-top", Material.LIME_BED,
                        "TELEPORT_HOME", displaySlot, homeData));
                inventory.setItem(bottomSlots.get(i), buildConfiguredItem("gui.set-bottom", Material.LIME_DYE,
                        "CONFIRM_DELETE", displaySlot, homeData));

            } else if (displaySlot <= maxHomes) {
                // Unlocked Empty Slot
                inventory.setItem(topSlots.get(i), buildConfiguredItem("gui.empty-top", Material.WHITE_BED,
                        "SET_EMPTY", displaySlot, null));
                inventory.setItem(bottomSlots.get(i), buildConfiguredItem("gui.empty-bottom", Material.GRAY_DYE,
                        "SET_EMPTY", displaySlot, null));

            } else {
                // Locked Slot
                inventory.setItem(topSlots.get(i), buildConfiguredItem("gui.locked-top", Material.RED_BED,
                        "LOCKED", displaySlot, null));
                inventory.setItem(bottomSlots.get(i), buildConfiguredItem("gui.locked-bottom", Material.RED_DYE,
                        "LOCKED", displaySlot, null));
            }
        }

        int maxPages = plugin.getConfig().getInt("max-pages", 10);

        if (plugin.getConfig().getBoolean("gui.navigation.center-item.enabled", true)) {
            int centerSlot = plugin.getConfig().getInt("gui.navigation.center-item.slot", 31);
            Material centerMat = getMaterial(plugin.getConfig().getString("gui.navigation.center-item.material"), Material.WHITE_STAINED_GLASS_PANE);
            String centerName = applyNavPlaceholders(plugin.getConfig().getString("gui.navigation.center-item.name", "&7Page %page%/%max_pages%"), maxPages);
            List<String> centerLore = applyNavPlaceholdersList(plugin.getConfig().getStringList("gui.navigation.center-item.lore"), maxPages);
            inventory.setItem(centerSlot, createItem(centerMat, centerName, centerLore, "NONE", -1));
        }

        if (page > 1) {
            int prevSlot = plugin.getConfig().getInt("gui.navigation.prev-page.slot", 27);
            Material prevMat = getMaterial(plugin.getConfig().getString("gui.navigation.prev-page.material"), Material.ARROW);
            String prevName = applyNavPlaceholders(plugin.getConfig().getString("gui.navigation.prev-page.name", "&a&l« Previous Page"), maxPages);
            List<String> prevLore = applyNavPlaceholdersList(plugin.getConfig().getStringList("gui.navigation.prev-page.lore"), maxPages);
            inventory.setItem(prevSlot, createItem(prevMat, prevName, prevLore, "PREV_PAGE", -1));
        }

        if (page < maxPages) {
            int nextSlot = plugin.getConfig().getInt("gui.navigation.next-page.slot", 35);
            Material nextMat = getMaterial(plugin.getConfig().getString("gui.navigation.next-page.material"), Material.ARROW);
            String nextName = applyNavPlaceholders(plugin.getConfig().getString("gui.navigation.next-page.name", "&a&lNext Page »"), maxPages);
            List<String> nextLore = applyNavPlaceholdersList(plugin.getConfig().getStringList("gui.navigation.next-page.lore"), maxPages);
            inventory.setItem(nextSlot, createItem(nextMat, nextName, nextLore, "NEXT_PAGE", -1));
        }
    }

    private ItemStack buildConfiguredItem(String path, Material fallbackMat, String action, int slot, HomeData data) {
        Material mat = getMaterial(plugin.getConfig().getString(path + ".material"), fallbackMat);
        String rawName = plugin.getConfig().getString(path + ".name", "&aHome %slot%");
        List<String> rawLore = plugin.getConfig().getStringList(path + ".lore");

        String name = applySlotPlaceholders(rawName, slot, data);
        List<String> lore = new ArrayList<>();
        for (String line : rawLore) {
            lore.add(applySlotPlaceholders(line, slot, data));
        }
        return createItem(mat, name, lore, action, slot);
    }

    private String applySlotPlaceholders(String text, int slot, HomeData data) {
        String out = text.replace("%slot%", String.valueOf(slot));
        if (data != null) {
            Location loc = data.getLocation();
            out = out.replace("%name%", data.getName())
                    .replace("%world%", loc.getWorld() != null ? loc.getWorld().getName() : "world")
                    .replace("%x%", String.valueOf(loc.getBlockX()))
                    .replace("%y%", String.valueOf(loc.getBlockY()))
                    .replace("%z%", String.valueOf(loc.getBlockZ()));
        } else {
            out = out.replace("%name%", "home" + slot)
                    .replace("%world%", "-")
                    .replace("%x%", "0")
                    .replace("%y%", "0")
                    .replace("%z%", "0");
        }
        return out;
    }

    private String applyNavPlaceholders(String text, int maxPages) {
        return text.replace("%page%", String.valueOf(page))
                .replace("%max_pages%", String.valueOf(maxPages))
                .replace("%prev_page%", String.valueOf(Math.max(1, page - 1)))
                .replace("%next_page%", String.valueOf(Math.min(maxPages, page + 1)));
    }

    private List<String> applyNavPlaceholdersList(List<String> lines, int maxPages) {
        List<String> out = new ArrayList<>();
        for (String line : lines) {
            out.add(applyNavPlaceholders(line, maxPages));
        }
        return out;
    }

    private Material getMaterial(String matName, Material fallback) {
        if (matName == null || matName.isEmpty()) return fallback;
        Material mat = Material.matchMaterial(matName.toUpperCase());
        return mat != null ? mat : fallback;
    }

    private ItemStack createItem(Material material, String name, List<String> lore, String action, int slotNum) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ColorUtil.color(name));
            if (lore != null && !lore.isEmpty()) {
                meta.setLore(ColorUtil.colorList(lore));
            }
            PersistentDataContainer pdc = meta.getPersistentDataContainer();
            if (action != null) {
                pdc.set(ACTION_KEY, PersistentDataType.STRING, action);
            }
            if (slotNum != -1) {
                pdc.set(SLOT_NUM_KEY, PersistentDataType.INTEGER, slotNum);
            }
            pdc.set(PAGE_NUM_KEY, PersistentDataType.INTEGER, page);
            item.setItemMeta(meta);
        }
        return item;
    }

    public int getPage() {
        return page;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
