package dev.arun.nexhomes;

import dev.arun.nexhomes.commands.HomeCommands;
import dev.arun.nexhomes.listeners.GUIListener;
import dev.arun.nexhomes.manager.HomeManager;
import org.bukkit.plugin.java.JavaPlugin;

public final class NexHomes extends JavaPlugin {

    private HomeManager homeManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        this.homeManager = new HomeManager(this);

        HomeCommands commands = new HomeCommands(this);
        getCommand("homes").setExecutor(commands);
        getCommand("sethome").setExecutor(commands);
        getCommand("delhome").setExecutor(commands);
        getCommand("home").setExecutor(commands);
        getCommand("home").setTabCompleter(commands);
        getCommand("delhome").setTabCompleter(commands);
        getCommand("nexhomes").setExecutor(commands);

        getServer().getPluginManager().registerEvents(new GUIListener(this), this);
    }

    public HomeManager getHomeManager() {
        return homeManager;
    }
}
